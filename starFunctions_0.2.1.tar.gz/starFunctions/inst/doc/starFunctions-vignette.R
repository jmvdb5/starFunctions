## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
# Include the Library
library(starFunctions)

## If you downloaded the package locally install it like the following, making sure the .tar.gz file is in your directory: ##

# Load devtools
library(devtools)

# Install the package from the compressed file
install_local("starFunctions_0.2.0.tar.gz")

# Import the dataset
data("starData")

## -----------------------------------------------------------------------------
# Using starDistMainSeq() 
test1 <- starDistMainSeq(0.0005, 16.6)
test1

# Using starDistMainSeq() with the dataset
test2 <- starDistMainSeq(starData$Luminosity[1],starData$Absolute.Magnitude[1])
test2

## -----------------------------------------------------------------------------
# Using starDist() 
test3 <- starDist(3.846e26, 5778, 4.83, -0.0452)
test3


## -----------------------------------------------------------------------------
# Using starDistMainSeq() 
bolCorrApprox(8800)

test4 <- bolCorrApprox(2800)
test4


## -----------------------------------------------------------------------------
# Using starDistMainSeq() 
starSurfaceArea(0.16)

test5 <- starSurfaceArea(0.102)
test5


