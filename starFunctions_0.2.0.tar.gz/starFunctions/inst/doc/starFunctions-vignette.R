## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
# Include the Library
library(starFunctions)

# Import the dataset
data("starData")

## -----------------------------------------------------------------------------
# Using starDistMainSeq() 
test1 <- starDistMainSeq(0.0005, 16.6)
test1

# Using starDistMainSeq() with the dataset
test2 <- starDistMainSeq(starData$Luminosity[1],starData$Absolute.Magnitude[1])
test2

## -----------------------------------------------------------------------------
# Using starDist() 
test3 <- starDist(3.846e26, 5778, 4.83, -0.0452)
test3


## -----------------------------------------------------------------------------
# Using starDistMainSeq() 
bolCorrApprox(8800)

test4 <- bolCorrApprox(2800)
test4


